This is the legacy version that needs to be ran manually in the javascript console or as a bookmarklet. Features go up to version 1.4. 

To get the latest features, please use the Google Chrome extension, which can be downloaded from the web store here: 
https://chrome.google.com/webstore/detail/talk-to-chatgpt/hodadfhfagpiemkeoliaelelfbboamlk
